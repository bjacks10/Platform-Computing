<html>
  <head>
    <meta charset="utf-8">
    <link type = "text/css" rel = "stylesheet" href= "styles.css" media="screen">
    <title>Winter Page: Travel Website</title>
  </head>
  <body>
 <!---->
 <div id="skipnav">
   <a href ="#main">Skip to main content</a>
 </div>
 <div id="border">
    <div  id="winterbanner">
 <h1 id="subpage">Winter Vacation Destinations</h1>
 <nav>
  <ul>
    <li><a href="index.html">Home</a></li>
    <li><a href="tropical.html">Tropical</a></li>
    <li><a href="winter.html">Winter</a></li>
    <li><a href="abroad.html">Abroad</a></li>
    <li><a href="camping.html">Camping</a></li>
    <li><a href="cruise.html">Cruise</a></li>
  </ul>
</nav>
</div>